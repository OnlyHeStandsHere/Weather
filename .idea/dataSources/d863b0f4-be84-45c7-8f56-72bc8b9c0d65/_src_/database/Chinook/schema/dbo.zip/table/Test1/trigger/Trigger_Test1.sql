
CREATE TRIGGER [dbo].[Trigger_Test1]
    ON [dbo].[Test1]
    AFTER UPDATE
    AS
    BEGIN
		UPDATE dbo.Test1
			SET UpdateSource = 'a computer',
				UpdateDTS = SYSDATETIME(),
				UpdateBy = 'joe'
		WHERE id IN (SELECT id FROM inserted)
    END
GO
